package test;

public class GenerateFxml {

}
